<?php

namespace App\Providers;
use Illuminate\Http\Request;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;

class AllControlServiceProvider extends ServiceProvider
{
    public function boot(Request $request)
    {

    }
}
