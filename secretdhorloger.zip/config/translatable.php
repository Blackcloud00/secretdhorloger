<?php
return [
  'locales' => [
    'fr',
    'en',
    'de',
  ]
];
