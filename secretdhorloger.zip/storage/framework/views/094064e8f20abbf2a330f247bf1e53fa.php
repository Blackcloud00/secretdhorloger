<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Ajout d'un curseur</h1>
          </div>
        </div>
        <?php if(session()->get('success')): ?>
        <div class="row mt-3 mb-1 ">
            <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
        </div>
      <?php endif; ?>
      <?php if($errors): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mb-1 ">
            <div class="alert alert-danger"><?php echo e($error); ?></div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      </div>
    </section>
    <section class="content">
        <form action="<?php echo e(route("panel.categorie.update",$categorie->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
           <div class="row">
                <div class="col-md-12">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Données du curseur</h3>
                    </div>
                    <div class="card-body row">
                      <div class="form-group col-xl-6">
                        <label for="c_name_en">Nom EN</label>
                        <input type="text" name="c_name_en" required id="c_name_en" value="<?php echo e($categorie->name_en ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_name_fr">Nom FR</label>
                        <input type="text" id="c_name_fr" required name="c_name_fr" value="<?php echo e($categorie->name_fr ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_name_de">Nom DE</label>
                        <input type="text" id="c_name_de" required name="c_name_de" value="<?php echo e($categorie->name_de ?? ''); ?>" class="form-control">
                      </div>
                      <?php if(!empty($categories) && count($categories) > 0): ?>
                      <div class="form-group col-xl-6">
                        <label for="c_parent">Parent</label>
                        <select id="c_parent" name="c_parent" class="form-control custom-select">
                            <?php if(empty($categorie->parent)): ?>
                            <option selected value="">Select</option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($categorie->parent == $item->id): ?>
                            <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->name_fr); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($item->id); ?>" ><?php echo e($item->name_fr); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="">--</option>
                        </select>
                      </div>
                      <?php endif; ?>
                      <div class="form-group col-xl-6">
                        <label for="c_seo_title_en">Seo Title EN</label>
                        <input type="text" id="c_seo_title_en"  name="c_seo_title_en" value="<?php echo e($categorie->seo_title_en ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_seo_title_fr">Seo Title FR</label>
                        <input type="text" id="c_seo_title_fr"  name="c_seo_title_fr" value="<?php echo e($categorie->seo_title_fr ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_seo_title_de">Seo Title DE</label>
                        <input type="text" id="c_seo_title_de"  name="c_seo_title_de" value="<?php echo e($categorie->seo_title_de ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_seo_desc_en">Seo Desc EN</label>
                        <textarea type="text" id="c_seo_desc_en"  name="c_seo_desc_en" class="form-control"><?php echo e($categorie->seo_desc_en ?? ''); ?></textarea>
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_seo_desc_fr">Seo Desc FR</label>
                        <textarea type="text" id="c_seo_desc_fr"  name="c_seo_desc_fr" class="form-control"><?php echo e($categorie->seo_desc_fr ?? ''); ?></textarea>
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_seo_desc_de">Seo Desc DE</label>
                        <textarea type="text" id="c_seo_desc_de"  name="c_seo_desc_de" class="form-control"><?php echo e($categorie->seo_desc_de ?? ''); ?></textarea>
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_seo_keyword_en">Seo Keyword EN</label>
                        <input type="text" id="c_seo_keyword_en"  name="c_seo_keyword_en" value="<?php echo e($categorie->seo_keyword_en ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_seo_keyword_fr">Seo Keyword FR</label>
                        <input type="text" id="c_seo_keyword_fr"  name="c_seo_keyword_fr" value="<?php echo e($categorie->seo_keyword_fr ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_seo_keyword_de">Seo Keyword DE</label>
                        <input type="text" id="c_seo_keyword_de"  name="c_seo_keyword_de" value="<?php echo e($categorie->seo_keyword_de ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="c_status">Statut</label>
                        <select id="c_status" name="c_status" required class="form-control custom-select">
                          <option selected value="<?php echo e($categorie->status ?? ''); ?>"><?php echo e($status[$categorie->status]); ?></option>
                          <?php if($categorie->status != "1"): ?>
                          <option value="1">Publier</option>
                          <?php endif; ?>
                          <?php if($categorie->status != "0"): ?>
                          <option value="0">Projet</option>
                          <?php endif; ?>
                        </select>

                      </div>
                    </div>
                  </div>
                </div>
           </div>
           <div class="row">
                <div class="col-12">
                <a href="#" class="btn btn-secondary">Annuler</a>
                <input type="submit" value="Créer" class="btn btn-success float-right">
                </div>
           </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/backend/pages/categorie/edit.blade.php ENDPATH**/ ?>