    

    <?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>Ajout d'un produit</h1>
              </div>
            </div>
          </div>
        </section>
        <div class="col-md-12">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#product" data-toggle="tab">Produit Settings</a></li>
                  <li class="nav-item"><a class="nav-link " href="#french" data-toggle="tab">French</a></li>
                  <li class="nav-item"><a class="nav-link" href="#english" data-toggle="tab">English</a></li>
                  <li class="nav-item"><a class="nav-link" href="#german" data-toggle="tab">German</a></li>
                </ul>
              </div>
              <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane active" id="product">
                        <form action="<?php echo e(route("panel.product.update", $product->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                        <?php if(session()->get('success')): ?>
                        <div class="row mt-3 mb-1 ">
                            <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
                        </div>
                      <?php endif; ?>
                      <?php if($errors): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row mb-1 ">
                            <div class="alert alert-danger"><?php echo e($error); ?></div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                           <div class="row">
                                <div class="col-md-12">
                                  <div class="card card-primary">
                                    <div class="card-header">
                                      <h3 class="card-title">Données du curseur</h3>
                                    </div>
                                    <div class="card-body row">
                                      <div class="form-group col-xl-3">
                                        <label for="p_name">Titre du curseur</label>
                                        <input type="text" name="p_name" required id="p_name" value="<?php echo e($product->name ?? ''); ?>" class="form-control">
                                      </div>
                                      <?php if(!empty($categories) && count($categories) > 0): ?>
                                      <div class="form-group col-xl-3">
                                        <label for="p_categorie">Categories</label>
                                        <select id="p_categorie" name="p_categorie" class="form-control custom-select">
                                          <option selected value="-" disabled>Select</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->id ==  $product->category_id ): ?>
                                            <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->name_fr); ?></option>
                                            <?php else: ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name_fr); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                      </div>
                                      <?php endif; ?>
                                      <div class="form-group col-xl-2">
                                        <label for="p_sku">SKU</label>
                                        <input type="text" id="p_sku" name="p_sku" value="<?php echo e($product->sku ?? ''); ?>" class="form-control">
                                      </div>
                                      <div class="form-group col-xl-2">
                                        <label for="p_price">Price</label>
                                        <input type="text" id="p_price" name="p_price" value="<?php echo e($product->price ?? ''); ?>" class="form-control">
                                      </div>
                                      <div class="form-group col-xl-2">
                                        <label for="p_status">Statut</label>
                                        <select id="p_status" name="p_status" required class="form-control custom-select">
                                            <option selected value="<?php echo e($product->status ?? ''); ?>"><?php echo e($status[$product->status]); ?></option>
                                            <?php if($product->status != "1"): ?>
                                            <option value="1">Publier</option>
                                            <?php endif; ?>
                                            <?php if($product->status != "0"): ?>
                                            <option value="0">Projet</option>
                                            <?php endif; ?>
                                        </select>
                                      </div>
                                      <?php
                                      $productArray = json_decode(json_encode($product), true);
                                      ?>
                                         <?php for($i = 1; $i <= 5; $i++): ?>
                                         <div class="form-group col-xl-3">
                                             <div class="row">
                                                 <div class="col-6">
                                                     <input type="text" class="custom-file-input hidden" value="<?php echo e($productArray["img_" . $i] ?? ''); ?>" name="r_img_<?php echo e($i); ?>" id="r_img_<?php echo e($i); ?>">

                                                     <img src="<?php echo e(asset($productArray["img_" . $i] ?? 'upload/resimyok.jpg')); ?>" style="width: 200; height: 200px;" alt="">
                                                 </div>
                                                 <div class="col-12">
                                                     <label for="p_img_<?php echo e($i); ?>">Image du Curseur <b><?php echo e($i); ?></b></label>
                                                     <div class="input-group">
                                                     <div class="custom-file">
                                                         <input type="file" class="custom-file-input"  name="p_img_<?php echo e($i); ?>" id="p_img_<?php echo e($i); ?>">
                                                         <label class="custom-file-label" for="p_img_<?php echo e($i); ?>">Choisir le fichier (540x458)</label>
                                                     </div>
                                                     <div class="input-group-append">
                                                         <span class="input-group-text">Télécharger</span>
                                                     </div>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                         <?php endfor; ?>
                                    </div>
                                  </div>
                                </div>
                           </div>
                           <div class="row">
                                <div class="col-12">
                                <a href="#" class="btn btn-secondary">Annuler</a>
                                <input type="submit" value="Créer" class="btn btn-success float-right">
                                </div>
                           </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="french">
                        <?php
                            $frmRoute = route("panel.productcontent.store");
                            $frmType = 'POST';
                            if (!empty($productcontent_fr)) {
                                $frmRoute = route("panel.productcontent.update", $productcontent_fr->id);
                                $frmType = "PUT";
                            }
                        ?>
                        <form action="<?php echo e($frmRoute); ?>" method="POST" enctype="multipart/form-data">
                           <?php echo csrf_field(); ?>
                           <?php echo method_field($frmType); ?>
                           <div class="row">
                                <div class="col-md-12">
                                  <div class="card card-primary">
                                    <div class="card-header">
                                      <h3 class="card-title">Données du curseur</h3>
                                    </div>
                                    <div class="card-body row">
                                        <?php if(!empty($products) && count($products) > 0): ?>
                                        <div class="form-group col-xl-6">
                                          <label for="p_id">Products Select</label>
                                          <select id="p_id" name="p_id" required class="form-control custom-select">
                                            <option selected value="-" disabled>Select</option>
                                              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                        </div>
                                        <?php endif; ?>
                                      <div class="form-group col-xl-6 hidden" style="display: none;">
                                        <input type="text" name="p_lang" value="fr" id="p_lang"  class="form-control">
                                        <input type="text" name="p_id" value="<?php echo e($product->id); ?>" id="p_id"  class="form-control">
                                      </div>
                                      <div class="form-group col-xl-6">
                                        <label for="p_title">Titre du curseur</label>
                                        <input type="text" name="p_title" value="<?php echo e($productcontent_fr->title ?? ''); ?>" required id="p_title" class="form-control">
                                      </div>
                                      <div class="form-group col-xl-6">
                                        <label for="p_short_des">Short Des</label>
                                        <input type="text" id="p_short_des" value="<?php echo e($productcontent_fr->short_des ?? ''); ?>" required name="p_short_des" class="form-control">
                                      </div>
                                      <div class="form-group col-xl-6">
                                        <label for="p_description">Description</label>
                                        <textarea name="p_description" class="form-control p_description"><?php echo e($productcontent_fr->description ?? ''); ?></textarea>
                                      </div>

                                      <div class="form-group col-xl-6">
                                        <label for="p_technic_des">Technic Descrirption</label>
                                        <textarea name="p_technic_des" cols="30" rows="5"  class="form-control p_description"><?php echo e($productcontent_fr->technic_des ?? ''); ?></textarea>
                                      </div>
                                      <div class="form-group col-xl-6">
                                        <label for="p_seo_title">Seo Title</label>
                                        <textarea name="p_seo_title" id="p_seo_title" cols="30" rows="5"  class="form-control "><?php echo e($productcontent_fr->seo_title ?? ''); ?></textarea>
                                      </div>
                                      <div class="form-group col-xl-6">
                                        <label for="p_seo_desc">Seo Description</label>
                                        <textarea name="p_seo_desc" id="p_seo_desc" cols="30" rows="5"  class="form-control"><?php echo e($productcontent_fr->seo_desc ?? ''); ?></textarea>
                                      </div>
                                      <div class="form-group col-xl-6">
                                        <label for="p_seo_keyword">Seo Keyword</label>
                                        <textarea name="p_seo_keyword" id="p_seo_keyword" cols="30" rows="5"  class="form-control"><?php echo e($productcontent_fr->seo_keyword ?? ''); ?></textarea>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                           </div>
                           <div class="row">
                                <div class="col-12">
                                <a href="#" class="btn btn-secondary">Annuler</a>
                                <input type="submit" value="Créer" class="btn btn-success float-right">
                                </div>
                           </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="english">
                        <?php
                        $frmRoute = route("panel.productcontent.store");
                        $frmType = 'POST';
                        if (!empty($productcontent_en)) {
                            $frmRoute = route("panel.productcontent.update", $productcontent_en->id);
                            $frmType = "PUT";
                        }
                    ?>
                    <form action="<?php echo e($frmRoute); ?>" method="POST" enctype="multipart/form-data">
                       <?php echo csrf_field(); ?>
                       <?php echo method_field($frmType); ?>
                       <div class="row">
                            <div class="col-md-12">
                              <div class="card card-primary">
                                <div class="card-header">
                                  <h3 class="card-title">Données du curseur</h3>
                                </div>
                                <div class="card-body row">
                                    <?php if(!empty($products) && count($products) > 0): ?>
                                    <div class="form-group col-xl-6">
                                      <label for="p_id">Products Select</label>
                                      <select id="p_id" name="p_id" required class="form-control custom-select">
                                        <option selected value="-" disabled>Select</option>
                                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                    </div>
                                    <?php endif; ?>
                                  <div class="form-group col-xl-6 hidden" style="display: none;">
                                    <input type="text" name="p_lang" value="en" id="p_lang"  class="form-control">
                                    <input type="text" name="p_id" value="<?php echo e($product->id); ?>" id="p_id"  class="form-control">
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_title">Titre du curseur</label>
                                    <input type="text" name="p_title" value="<?php echo e($productcontent_en->title ?? ''); ?>" required id="p_title" class="form-control">
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_short_des">Short Des</label>
                                    <input type="text" id="p_short_des" value="<?php echo e($productcontent_en->short_des ?? ''); ?>" required name="p_short_des" class="form-control">
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_description">Description</label>
                                    <textarea name="p_description"  cols="30" rows="5"  class="form-control p_description"><?php echo e($productcontent_en->description ?? ''); ?></textarea>
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_technic_des">Technic Descrirption</label>
                                    <textarea name="p_technic_des" id="p_technic_des" cols="30" rows="5"  class="form-control p_description"><?php echo e($productcontent_en->technic_des ?? ''); ?></textarea>
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_seo_title">Seo Title</label>
                                    <textarea name="p_seo_title" id="p_seo_title" cols="30" rows="5"  class="form-control"><?php echo e($productcontent_en->seo_title ?? ''); ?></textarea>
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_seo_desc">Seo Description</label>
                                    <textarea name="p_seo_desc" id="p_seo_desc" cols="30" rows="5"  class="form-control"><?php echo e($productcontent_en->seo_desc ?? ''); ?></textarea>
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_seo_keyword">Seo Keyword</label>
                                    <textarea name="p_seo_keyword" id="p_seo_keyword" cols="30" rows="5"  class="form-control"><?php echo e($productcontent_en->seo_keyword ?? ''); ?></textarea>
                                  </div>
                                </div>
                              </div>
                            </div>
                       </div>
                       <div class="row">
                            <div class="col-12">
                            <a href="#" class="btn btn-secondary">Annuler</a>
                            <input type="submit" value="Créer" class="btn btn-success float-right">
                            </div>
                       </div>
                    </form>
                    </div>
                    <div class="tab-pane" id="german">
                        <?php
                        $frmRoute = route("panel.productcontent.store");
                        $frmType = 'POST';
                        if (!empty($productcontent_de)) {
                            $frmRoute = route("panel.productcontent.update", $productcontent_de->id);
                            $frmType = "PUT";
                        }
                    ?>
                    <form action="<?php echo e($frmRoute); ?>" method="POST" enctype="multipart/form-data">
                       <?php echo csrf_field(); ?>
                       <?php echo method_field($frmType); ?>
                       <div class="row">
                            <div class="col-md-12">
                              <div class="card card-primary">
                                <div class="card-header">
                                  <h3 class="card-title">Données du curseur</h3>
                                </div>
                                <div class="card-body row">
                                    <?php if(!empty($products) && count($products) > 0): ?>
                                    <div class="form-group col-xl-6">
                                      <label for="p_id">Products Select</label>
                                      <select id="p_id" name="p_id" required class="form-control custom-select">
                                        <option selected value="-" disabled>Select</option>
                                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                    </div>
                                    <?php endif; ?>
                                  <div class="form-group col-xl-6 hidden" style="display: none;">
                                    <input type="text" name="p_lang" value="de" id="p_lang"  class="form-control">
                                    <input type="text" name="p_id" value="<?php echo e($product->id); ?>" id="p_id"  class="form-control">
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_title">Titre du curseur</label>
                                    <input type="text" name="p_title" value="<?php echo e($productcontent_de->title ?? ''); ?>" required id="p_title" class="form-control">
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_short_des">Short Des</label>
                                    <input type="text" id="p_short_des" value="<?php echo e($productcontent_de->short_des ?? ''); ?>" required name="p_short_des" class="form-control">
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_description">Description</label>
                                    <textarea name="p_description" cols="30" rows="5"  class="form-control p_description"><?php echo e($productcontent_de->description ?? ''); ?></textarea>
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_technic_des">Technic Descrirption</label>
                                    <textarea name="p_technic_des" id="p_technic_des" cols="30" rows="5"  class="form-control p_description"><?php echo e($productcontent_de->technic_des ?? ''); ?></textarea>
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_seo_title">Seo Title</label>
                                    <textarea name="p_seo_title" id="p_seo_title" cols="30" rows="5"  class="form-control"><?php echo e($productcontent_de->seo_title ?? ''); ?></textarea>
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_seo_desc">Seo Description</label>
                                    <textarea name="p_seo_desc" id="p_seo_desc" cols="30" rows="5"  class="form-control"><?php echo e($productcontent_de->seo_desc ?? ''); ?></textarea>
                                  </div>
                                  <div class="form-group col-xl-6">
                                    <label for="p_seo_keyword">Seo Keyword</label>
                                    <textarea name="p_seo_keyword" id="p_seo_keyword" cols="30" rows="5"  class="form-control"><?php echo e($productcontent_de->seo_keyword ?? ''); ?></textarea>
                                  </div>
                                </div>
                              </div>
                            </div>
                       </div>
                       <div class="row">
                            <div class="col-12">
                            <a href="#" class="btn btn-secondary">Annuler</a>
                            <input type="submit" value="Créer" class="btn btn-success float-right">
                            </div>
                       </div>
                    </form>
                    </div>
                </div>
              </div>
            </div>
          </div>

    <?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/backend/pages/product/edit.blade.php ENDPATH**/ ?>