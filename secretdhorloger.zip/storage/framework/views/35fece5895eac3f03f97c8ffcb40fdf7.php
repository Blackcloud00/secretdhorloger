<?php $__env->startSection('content'); ?>
<div class="content-wrapper pt-5">
    <section class="content">
        <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header d-flex justify-between">
                  <h3 class="card-title">Liste des Carrousel</h3>
                  <a href="<?php echo e(route('panel.slider.create')); ?>" class="btn btn-success" style="position: relative; margin-left:auto;">Nouveau Carrousel</a>
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-hover text-nowrap">
                    <thead>
                    <tr>
                      <th>ID</th>
                      <th>Titre</th>
                      <th>Image</th>
                      <th>Lang</th>
                      <th>Slug</th>
                      <th>Contenu</th>
                      <th>Statut</th>
                      <th>Modifier</th>
                      <th>Supprimer</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($sliders) && $sliders->count() > 0): ?>
                         <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($sld->id); ?></td>
                            <td><?php echo e($sld->name); ?></td>
                            <td class="py-1">
                              <img style="max-height: 100px;" src="<?php echo e(asset($sld->image)); ?>" alt="<?php echo e($sld->name); ?>">
                            </td>
                            <td><?php echo e($sld->lang); ?></td>
                            <td><?php echo e($sld->text_key); ?></td>
                            <td><?php echo e(substr($sld->content, 0, 55)); ?>...</td>
                            <td><span class="tag tag-<?php echo e($sld->status == '1' ? 'success' : 'danger'); ?>"><?php echo e($sld->status == '1' ? 'published' : 'draft'); ?></span></td>
                            <td>
                                <a href="<?php echo e(route('panel.slider.edit', $sld->id)); ?>" class="btn btn-success">Modifier</a>
                            </td>
                            <td>
                                <form action="<?php echo e(route('panel.slider.destroy', $sld->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Supprimer</button>
                                </form>
                            </td>
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/backend/pages/slider/index.blade.php ENDPATH**/ ?>