<?php $__env->startSection('content'); ?>
<div class="content-wrapper pt-5">
    <section class="content">
        <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header d-flex justify-between">
                  <h3 class="card-title">Liste des categorie</h3>
                  <a href="<?php echo e(route('panel.categorie.create')); ?>" class="btn btn-success" style="position: relative; margin-left:auto;">Ajouter Categorie</a>
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-hover text-nowrap">
                    <thead>
                    <tr>
                      <th>ID</th>
                      <th>Nom EN</th>
                      <th>Nom FR</th>
                      <th>Nom DE</th>
                      <th>Slug</th>
                      <th>Parent Name</th>
                      <th>Statut</th>
                      <th>Modifier</th>
                      <th>Supprimer</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($categories) && $categories->count() > 0): ?>
                         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($sld->id); ?></td>
                            <td><?php echo e($sld->name_en); ?></td>
                            <td><?php echo e($sld->name_fr); ?></td>
                            <td><?php echo e($sld->name_de); ?></td>
                            <td><?php echo e($sld->slug); ?></td>
                             <?php
                                $catName = "";
                                foreach ($categories as  $catItem) {

                                    if($catItem->id == $sld->parent){
                                        $catName = $catItem->name_fr;
                                    }
                                }
                             ?>
                            <td><b><?php echo e($catName); ?></b></td>
                            <td><span class="tag tag-<?php echo e($sld->status == '1' ? 'success' : 'danger'); ?>"><?php echo e($sld->status == '1' ? 'published' : 'draft'); ?></span></td>
                            <td>
                                <a href="<?php echo e(route('panel.categorie.edit', $sld->id)); ?>" class="btn btn-success">Modifier</a>
                            </td>
                            <td>
                                <form action="<?php echo e(route('panel.categorie.destroy', $sld->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Supprimer</button>
                                </form>
                            </td>
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/backend/pages/categorie/index.blade.php ENDPATH**/ ?>