<?php $__env->startSection("content"); ?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="row breadcrumb_box  align-items-center">
                    <div class="col-lg-6 col-md-6 col-sm-12 text-center text-md-left">
                        <h2 class="breadcrumb-title"><?php echo e($langData["wishlist"]); ?></h2>
                    </div>
                    <div class="col-lg-6  col-md-6 col-sm-12">
                        <ul class="breadcrumb-list text-center text-md-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('homepage')); ?>"><?php echo e($langData["homepage"]); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e($langData["wishlist"]); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="cart-main-area pt-100px pb-100px">
    <div class="container">
        <h3 class="cart-page-title"><?php echo e($langData["w_your_cart_items"]); ?></h3>
        <div class="row">
            <div class="col-12">
                <?php if(session()->get('success')): ?>
                    <div class="alert alert-success"><?php echo e($langData[session()->get('success')]); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="table-content table-responsive cart-table-content">
                        <table>
                            <thead>
                                <tr>
                                    <th><?php echo e($langData["image"]); ?></th>
                                    <th><?php echo e($langData["product_name"]); ?></th>
                                    <th><?php echo e($langData["until_price"]); ?></th>
                                    <th><?php echo e($langData["qty"]); ?></th>
                                    <th><?php echo e($langData["subtotal"]); ?></th>
                                    <th><?php echo e($langData["delete_to_cart"]); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($wishlistItem): ?>
                                    <?php $__currentLoopData = $wishlistItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="product-thumbnail">
                                            <a href="#"><img class="img-responsive ml-3" src="<?php echo e(asset($item["image"])); ?>" alt="<?php echo e($item["name"]); ?>" /></a>
                                        </td>
                                        <td class="product-name"><a href="#"><?php echo e($item["name"]); ?></a></td>
                                        <td class="product-price-cart"><span class="amount"><?php echo e($item["price"]); ?> €</span></td>
                                        <td class="product-quantity">
                                            <form action="<?php echo e(route('wishlist.add')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="product_id" value="<?php echo e($key); ?>">
                                                <input type="hidden" name="product_price" value="<?php echo e($item['price']); ?>">
                                                <input type="hidden" name="product_qty" value="1">
                                                <div class="cart-plus-minus">
                                                    <input class="cart-plus-minus-box" type="text" name="qtybutton" value="<?php echo e($item["qty"]); ?>" />
                                                </div>
                                            </form>
                                        </td>
                                        <td class="product-subtotal"><?php echo e($item["qty"] * $item["price"]); ?> €</td>
                                        <td class="product-wishlist-cart">
                                            <form action="<?php echo e(route('wishlist.remove')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="text" hidden name="product_id" value="<?php echo e($key); ?>">
                                                <button type="submit"><?php echo e($langData["delete_to_cart"]); ?></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="container">
                            <div class="d-flex" style="width: 100%;display: flex;justify-content: space-between;margin-top: 20px;">
                                <h3><?php echo e($langData["total"]); ?> : <?php echo e($totalPrice); ?> €</h3>
                                <a href="<?php echo e(route("checkout")); ?>"><?php echo e($langData["submit"]); ?></a>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("frontend.layout.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/frontend/pages/wishlist.blade.php ENDPATH**/ ?>