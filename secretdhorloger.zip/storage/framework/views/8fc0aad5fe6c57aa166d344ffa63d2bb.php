    <div class="footer-area">
        <div class="footer-container">
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-lg-4 mb-md-30px mb-lm-30px" data-aos="fade-up" data-aos-delay="200">
                            <div class="single-wedge">
                                <h4 class="footer-herading"><?php echo e($sitesetting["title"]); ?></h4>
                                <p class="about-text"><?php echo e($sitesetting["description"]); ?></p>
                                <ul class="link-follow">
                                    <?php if(!is_null($sitesetting["facebook"])): ?>
                                    <li class="li">
                                        <a class="facebook icon-social-facebook" title="Facebook" target="_blank" href="<?php echo e($sitesetting["facebook"]); ?>"></a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if(!is_null($sitesetting["instagram"])): ?>
                                    <li class="li">
                                        <a class="instagram icon-social-instagram" title="instagram" target="_blank" href="<?php echo e($sitesetting["instagram"]); ?>"></a>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-3 mb-md-30px mb-lm-30px" data-aos="fade-up" data-aos-delay="400">
                            <div class="single-wedge">
                                <div class="footer-links">
                                    <div class="footer-row">
                                        <ul class="align-items-center">
                                            <li class="li"><a class="single-link" href="<?php echo e(route("homepage")); ?>"><?php echo e($langData["homepage"]); ?></a></li>
                                            <li class="li"><a class="single-link" href=<?php echo e(route("about")); ?>"><?php echo e($langData["about_us"]); ?></a></li>
                                            <li class="li"><a class="single-link" href="<?php echo e(route('products')); ?>"><?php echo e($langData["products"]); ?></a></li>
                                            <li class="li"><a class="single-link" href="<?php echo e(route('contact')); ?>"><?php echo e($langData["contact"]); ?></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">
                    <div class="row flex-sm-row-reverse">
                        <div class="col-md-6 text-left">
                            <p class="copy-text"><?php echo e($sitesetting["copyright"]); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/frontend/inc/footer.blade.php ENDPATH**/ ?>