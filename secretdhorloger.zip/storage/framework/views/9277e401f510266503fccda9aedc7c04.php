<?php $__env->startSection('content'); ?>
    <div class="breadcrumb-area">
        <?php if($page[0]->banner_img): ?>
            <img src="<?php echo e(asset($page[0]->banner_img ?? "")); ?>" style="position:absolute; right:0; top:0; width:100%; height:100%; z-index:0;
            opacity: 0.6;" alt="">
        <?php endif; ?>
        <div class="container" style="position: relative; z-index: 6; background-color: #f0f8ffb5;
        border-radius: 10px;">
            <div class="row">
                <div class="col-12">
                    <div class="row breadcrumb_box  align-items-center">
                        <div class="col-lg-6 col-md-6 col-sm-12 text-center text-md-left">
                            <h2 class="breadcrumb-title"><?php echo e($langData["contact"]); ?></h2>
                        </div>
                        <div class="col-lg-6  col-md-6 col-sm-12">
                            <ul class="breadcrumb-list text-center text-md-right">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('homepage')); ?>"><?php echo e($langData["homepage"]); ?></a></li>
                                <li class="breadcrumb-item active"><?php echo e($langData["contact"]); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="contact-area pb-100px pt-100px">
        <div class="container">
            <div class="contact-map mb-10">
                <div id="mapid" data-aos="fade-up" data-aos-delay="200">
                    <div class="mapouter">
                        <div class="gmap_canvas">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d552.4851828150679!2d4.222720130718989!3d45.74411147438645!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f4472e96a985bd%3A0x2abdc3a7567f6d8!2sSecret%20d&#39;horloger!5e0!3m2!1str!2str!4v1697289128912!5m2!1str!2str" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            <a href="<?php echo e($sitesetting["map_link"]); ?>"></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-row-2 row">
                <div class="col-lg-4 col-md-5 mb-lm-60px col-sm-12 col-xs-12 w-sm-100">
                    <div class="contact-info-wrap">
                        <h2 class="title" data-aos="fade-up" data-aos-delay="200"><?php echo e($langData["contact_info"]); ?></h2>
                        <div class="single-contact-info" data-aos="fade-up" data-aos-delay="200">
                            <div class="contact-info-inner">
                                <span class="sub-title"><?php echo e($langData["phone"]); ?>:</span>
                            </div>
                            <div class="contact-info-dec">
                                <p><a href="tel:<?php echo e(str_replace(' ','',$sitesetting["contact_phone"])); ?>"><?php echo e($sitesetting["contact_phone"]); ?></a></p>
                            </div>
                        </div>
                        <div class="single-contact-info" data-aos="fade-up" data-aos-delay="200">
                            <div class="contact-info-inner">
                                <span class="sub-title"><?php echo e($langData["email"]); ?>:</span>
                            </div>
                            <div class="contact-info-dec">
                                <p><a href="mailto://<?php echo e($sitesetting["contact_email"]); ?>"><?php echo e($sitesetting["contact_email"]); ?></a></p>
                            </div>
                        </div>
                        <div class="single-contact-info" data-aos="fade-up" data-aos-delay="200">
                            <div class="contact-info-inner">
                                <span class="sub-title"><?php echo e($langData["adress"]); ?>:</span>
                            </div>
                            <div class="contact-info-dec">
                                <a href="<?php echo e($sitesetting["map_link"]); ?>" title="<?php echo e($sitesetting["adress"]); ?>" target="_blank">
                                    <p><?php echo e($sitesetting["adress"]); ?></p>
                                </a>
                            </div>
                        </div>
                        <div class="contact-social">
                            <h3 class="title" data-aos="fade-up" data-aos-delay="200"><?php echo e($langData["follow_us"]); ?></h3>
                            <div class="social-info" data-aos="fade-up" data-aos-delay="200">
                                <ul class="d-flex">
                                    <?php if(!is_null($sitesetting["facebook"])): ?>
                                    <li class="li">
                                        <a class="facebook icon-social-facebook" title="Facebook" target="_blank" href="<?php echo e($sitesetting["facebook"]); ?>"></a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if(!is_null($sitesetting["instagram"])): ?>
                                    <li class="li">
                                        <a class="instagram icon-social-instagram" title="instagram" target="_blank" href="<?php echo e($sitesetting["instagram"]); ?>"></a>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-7 col-sm-12 col-xs-12">
                    <?php if(session()->has('message_key')): ?>
                    <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading"><?php echo e($langData[session()->get('message_key')]); ?></h4>
                    </div>
                    <?php endif; ?>
                    <?php if(count($errors)): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger" role="alert">
                            <h4 class="alert-heading"><?php echo e($langData[$error]); ?></h4>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="contact-form">
                        <div class="contact-title mb-30">
                            <h2 class="title" data-aos="fade-up" data-aos-delay="200"><?php echo e($langData["get_in_touch"]); ?></h2>
                        </div>
                        <form class="contact-form-style" id="contact-form" action="<?php echo e(route('contact.save')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
                                    <input name="name" placeholder="<?php echo e($langData["name"]); ?>*" type="text" />
                                </div>
                                <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
                                    <input name="email" placeholder="<?php echo e($langData["email"]); ?>*" type="email" />
                                </div>
                                <div class="col-lg-12" data-aos="fade-up" data-aos-delay="200">
                                    <input name="subject" placeholder="<?php echo e($langData["subject"]); ?>*" type="text" />
                                </div>
                                <div class="col-lg-12" data-aos="fade-up" data-aos-delay="200">
                                    <textarea name="message" placeholder="<?php echo e($langData["your_message"]); ?>*"></textarea>
                                    <button class="btn btn-primary btn-hover-dark mt-4" data-aos="fade-up" data-aos-delay="200" type="submit"><?php echo e($langData["send"]); ?></button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>