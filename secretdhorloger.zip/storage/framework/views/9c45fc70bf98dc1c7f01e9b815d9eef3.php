    

    <?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>Ajout d'un curseur</h1>
              </div>
            </div>
            <?php if(session()->get('success')): ?>
            <div class="row mt-3 mb-1 ">
                <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
            </div>
          <?php endif; ?>
          <?php if($errors): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mb-1 ">
                <div class="alert alert-danger"><?php echo e($error); ?></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          </div>
        </section>
        <section class="content">
            <form action="<?php echo e(route("panel.product.store")); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
               <div class="row">
                    <div class="col-md-12">
                      <div class="card card-primary">
                        <div class="card-header">
                          <h3 class="card-title">Données du curseur</h3>
                        </div>
                        <div class="card-body row">
                          <div class="form-group col-xl-6">
                            <label for="p_name">Titre du curseur</label>
                            <input type="text" name="p_name" required id="p_name" class="form-control">
                          </div>
                          <?php if(!empty($categories) && count($categories) > 0): ?>
                          <div class="form-group col-xl-6">
                            <label for="p_categorie">Categories</label>
                            <select id="p_categorie" name="p_categorie" class="form-control custom-select">
                              <option selected value="-" disabled>Select</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name_fr); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                          <?php endif; ?>
                        <?php for($i = 1; $i <= 5; $i++): ?>
                        <div class="form-group col-xl-6">
                            <label for="p_img_<?php echo e($i); ?>">Image du Curseur <b><?php echo e($i); ?></b></label>
                            <div class="input-group">
                              <div class="custom-file">
                                <input type="file" class="custom-file-input"  <?php if ($i == 1) { echo "required"; } ?>  name="p_img_<?php echo e($i); ?>" id="p_img_<?php echo e($i); ?>">
                                <label class="custom-file-label" for="p_img_<?php echo e($i); ?>">Choisir le fichier (540x458)</label>
                              </div>
                              <div class="input-group-append">
                                <span class="input-group-text">Télécharger</span>
                              </div>
                            </div>
                          </div>
                        <?php endfor; ?>
                          <div class="form-group col-xl-6">
                            <label for="p_sku">SKU</label>
                            <input type="text" id="p_sku" required name="p_sku" class="form-control">
                          </div>
                          <div class="form-group col-xl-6">
                            <label for="p_price">Price</label>
                            <input type="text" id="p_price" required name="p_price" class="form-control">
                          </div>
                          <div class="form-group col-xl-6">
                            <label for="p_status">Statut</label>
                            <select id="p_status" name="p_status" required class="form-control custom-select">
                              <option selected disabled>Sélectionnez une option</option>
                              <option value="1">Publier</option>
                              <option value="0">Projet</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
               </div>
               <div class="row">
                    <div class="col-12">
                    <a href="#" class="btn btn-secondary">Annuler</a>
                    <input type="submit" value="Créer" class="btn btn-success float-right">
                    </div>
               </div>
            </form>
        </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/backend/pages/product/add.blade.php ENDPATH**/ ?>