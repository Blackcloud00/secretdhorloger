<?php

if (!isset($home)) {
    $home = 2;
}

$urlCurrent = explode("/",url()->current());

    $urlCurrentLanguage = app()->getLocale();
    $urlCurrentPage = null;
    $urlCurrentSubPage = null;
    //dd($urlCurrent);

   if (count($urlCurrent) > 2) {
      $urlCurrentLanguage = $urlCurrent[3];

      if (isset($urlCurrent[4])) {
        $urlCurrentPage = $urlCurrent[4];
       }
    }

    if (count($urlCurrent) > 4 && isset($urlCurrent[5])){
        $urlCurrentSubPage = $urlCurrent[5];
    }

?>


<div class="header section">
    <div class="header-top section-fluid bg-black">
        <div class="container">
            <div class="row row-cols-lg-2 align-items-center">
                <div class="col text-center text-lg-left">
                    <div class="header-top-massege">
                        <p><?php echo e($sitesetting["title"]); ?></p>
                    </div>
                </div>
                <div class="col d-none d-lg-block">
                    <div class="header-top-set-lan-curr d-flex justify-content-end">
                        <div class="header-top-curr dropdown">
                            <button class="dropdown-toggle" data-bs-toggle="dropdown"> <?php echo e($langData["language"]); ?> : (<?php echo e(strtoupper(config('app.locale'))); ?>) <i
                                    class="ion-ios-arrow-down"></i></button>
                            <ul class="dropdown-menu dropdown-menu-right">
                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                 $langHref =  $item;
                                 if (!is_null($urlCurrentPage)) {
                                  $langHref = $item . "/" . $urlCurrentPage;
                                 }
                                 if (!is_null($urlCurrentSubPage)) {
                                    $langHref = $item . "/" . $urlCurrentPage .  "/" . $urlCurrentSubPage;
                                }
                                ?>
                                 <?php if(!is_null($urlCurrentPage) && is_null($urlCurrentSubPage)): ?>
                                 <li><a class="dropdown-item" href="../<?php echo e($langHref); ?>"><?php echo e($langData["lang_".$item]); ?></a></li>
                                 <?php elseif($home == 1): ?>
                                 <li><a class="dropdown-item" href="../<?php echo e($langHref); ?>"><?php echo e($langData["lang_".$item]); ?></a></li>
                                <?php elseif(!is_null($urlCurrentSubPage)): ?>
                                 <li><a class="dropdown-item" href="../../<?php echo e($langHref); ?>"><?php echo e($langData["lang_".$item]); ?></a></li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom d-none d-lg-block">
        <div class="container position-relative">
            <div class="row align-self-center">
                <div class="col-auto align-self-center">
                    <div class="header-logo">
                      <!--  <a href="<?php echo e(route('homepage')); ?>"><img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="Site Logo" /></a> -->
                      <a href="<?php echo e(route('homepage')); ?>" style="font-size: 30px; color: black; font-weight: 600; font-family: 'Inter', sans-serif;
                      font-family: 'Kalnia', serif;">Secret d'horloger</a>
                    </div>
                </div>
                <div class="col align-self-center">
                    <div class="header-actions">
                        <div class="header_account_list">
                            <div class="dropdown_search">
                                <form class="action-form" action="#">
                                    <input class="form-control" placeholder="Enter your search key" type="text">
                                    <button class="submit" type="submit"><i class="icon-magnifier"></i></button>
                                </form>
                            </div>
                        </div>
                        <a href="#offcanvas-mobile-menu" class="header-action-btn header-action-btn-menu offcanvas-toggle d-lg-none">
                            <i class="icon-menu"></i>
                        </a>
                        <a href="<?php echo e(route("wishlist")); ?>" class="header-action-btn pr-0">
                            <i class="icon-handbag"></i>
                            <?php if($countQty): ?>
                                <span class="header-action-num"><?php echo e($countQty); ?></span>
                            <?php endif; ?>
                            <!-- <span class="cart-amount">€30.00</span> -->
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom d-lg-none sticky-nav bg-white">
        <div class="container position-relative">
            <div class="row align-self-center">
                <div class="col-auto align-self-center">
                    <div class="header-logo">
                       <!-- <a href="<?php echo e(route('homepage')); ?>"><img src="<?php echo e(asset("assets/images/logo/logo.png")); ?>" alt="Site Logo" /></a>  -->
                        <a href="<?php echo e(route('homepage')); ?>" style="font-size: 30px; color: black; font-weight: 600; font-family: 'Inter', sans-serif;
                        font-family: 'Kalnia', serif;">Secret d'horloger</a>
                    </div>
                </div>
                <div class="col align-self-center">
                    <div class="header-actions">
                        <div class="header_account_list">
                            <div class="dropdown_search">
                                <form class="action-form" action="#">
                                    <input class="form-control" placeholder="Enter your search key" type="text">
                                    <button class="submit" type="submit"><i class="icon-magnifier"></i></button>
                                </form>
                            </div>
                        </div>
                        <a href="#offcanvas-mobile-menu" class="header-action-btn header-action-btn-menu offcanvas-toggle d-lg-none">
                            <i class="icon-menu"></i>
                        </a>
                        <a href="<?php echo e(route("wishlist")); ?>" class="header-action-btn pr-0">
                            <i class="icon-handbag"></i>
                            <?php if(session('wishlist')): ?>
                            <span class="header-action-num"><?php echo e(count(session('wishlist'))); ?></span>
                            <?php endif; ?>
                            <!-- <span class="cart-amount">€30.00</span> -->
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-black d-none d-lg-block sticky-nav">
        <div class="container position-relative">
            <div class="row">
                <div class="col-md-12 align-self-center">
                    <div class="main-menu">
                        <ul>
                            <li><a href="<?php echo e(route("homepage")); ?>"><?php echo e($langData["homepage"]); ?></i></a>
                            </li>
                            <li><a href="<?php echo e(route("about")); ?>"><?php echo e($langData["about_us"]); ?></a></li>
                            <li><a href="<?php echo e(route("products")); ?>"><?php echo e($langData["products"]); ?></a></li>
                            <li class="dropdown "><a href="<?php echo e(route('products')); ?>"> <?php echo e($langData["categories"]); ?> <i class="ion-ios-arrow-down"></i></a>
                                <ul class="sub-menu">
                                    <?php
                                        $faitPage = "";
                                    ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        if ($cat->id == 12) {
                                            $faitPage = $cat;
                                        }
                                    ?>
                                    <?php  $subMenu = ""; $arrowIcon = false; ?>
                                    <?php if(is_null($cat->parent)): ?>
                                    <li class="dropdown position-static"><a href="<?php echo e(route('productscategorie',$cat['slug'])); ?>"><?php echo e($cat["name_".app()->getLocale()]); ?>

                                       <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($cat->id == $subcat->parent && !is_null($subcat->parent)): ?>
                                       <?php
                                            $arrowIcon = true;
                                           $subMenu .= '<li><a href="'.route('productscategorie',$subcat['slug']).'">'.$subcat["name_".app()->getLocale()].'</a>
                                           </li>';
                                        ?>
                                       <?php endif; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   <?php if( $arrowIcon == true): ?>
                                   <i class="ion-ios-arrow-right"></i>
                                   <?php endif; ?>
                                    </a>
                                        <ul class="sub-menu sub-menu-2">
                                            <?php echo $subMenu ?>
                                        </ul>
                                    </li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <?php if($faitPage): ?>
                                <li><a href="<?php echo e(route('productscategorie',$faitPage->slug)); ?>"><?php echo e($langData["fait_main"]); ?></a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('contact')); ?>" ><?php echo e($langData["contact"]); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <div id="offcanvas-mobile-menu" class="offcanvas offcanvas-mobile-menu">
        <button class="offcanvas-close"></button>
        <div class="inner customScroll">
            <div class="offcanvas-menu mb-4">
                <ul>
                    <li><a href="<?php echo e(route("homepage")); ?>"><span class="menu-text"><?php echo e($langData["homepage"]); ?></span></a></li>
                    <li><a href="<?php echo e(route("about")); ?>"><?php echo e($langData["about_us"]); ?></a></li>
                    <li><a href="<?php echo e(route("products")); ?>"><span class="menu-text"><?php echo e($langData["categories"]); ?></span></a>
                        <ul class="sub-menu">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php  $subMenu = ""; $arrowIcon = false; ?>
                            <?php if(is_null($cat->parent)): ?>
                            <li><a href="<?php echo e(route('productscategorie',$cat['slug'])); ?>"><span class="menu-text"><?php echo e($cat["name_".app()->getLocale()]); ?></span></a>
                               <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if($cat->id == $subcat->parent && !is_null($subcat->parent)): ?>
                               <?php
                                    $arrowIcon = true;
                                   $subMenu .= '<li><a href="'.route('productscategorie',$subcat['slug']).'">'.$subcat["name_".app()->getLocale()].'</a>
                                   </li>';
                                ?>
                               <?php endif; ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php if( $arrowIcon == true): ?>
                           <?php endif; ?>
                            </a>
                                <ul class="sub-menu">
                                    <?php echo $subMenu ?>
                                </ul>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <?php if($faitPage): ?>
                      <li><a href="<?php echo e(route('productscategorie',$faitPage->slug)); ?>"><?php echo e($langData["fait_main"]); ?></a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo e(route('contact')); ?>" ><?php echo e($langData["contact"]); ?></a></li>
                </ul>
            </div>
            <div class="offcanvas-userpanel mt-8">
                <ul>
                    <li class="offcanvas-userpanel__role">
                        <a href="#"><?php echo e($langData["language"]); ?> : (<?php echo e(strtoupper(config('app.locale'))); ?>) <i class="ion-ios-arrow-down"></i></a>
                        <ul class="user-sub-menu">
                            <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                             $langHref =  $item;
                             if (!is_null($urlCurrentPage)) {
                              $langHref = $item . "/" . $urlCurrentPage;
                             }
                             if (!is_null($urlCurrentSubPage)) {
                                $langHref = $item . "/" . $urlCurrentPage .  "/" . $urlCurrentSubPage;
                            }
                            ?>
                             <?php if(!is_null($urlCurrentPage) && is_null($urlCurrentSubPage)): ?>
                             <li><a  href="../<?php echo e($langHref); ?>"><?php echo e($langData["lang_".$item]); ?></a></li>
                             <?php elseif($home == 1): ?>
                             <li><a  href="../<?php echo e($langHref); ?>"><?php echo e($langData["lang_".$item]); ?></a></li>
                            <?php elseif(!is_null($urlCurrentSubPage)): ?>
                             <li><a href="../../<?php echo e($langHref); ?>"><?php echo e($langData["lang_".$item]); ?></a></li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="offcanvas-social mt-auto">
                <ul>
                    <?php if(!is_null($sitesetting["facebook"])): ?>
                    <li>
                        <a href="<?php echo e($sitesetting["facebook"]); ?>"><i class="ion-social-facebook"></i></a>
                    </li>
                    <?php endif; ?>
                    <?php if(!is_null($sitesetting["instagram"])): ?>
                    <li>
                        <a href="<?php echo e($sitesetting["facebook"]); ?>"><i class="ion-social-facebook"></i></a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="offcanvas-overlay"></div>
<?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/frontend/inc/header.blade.php ENDPATH**/ ?>