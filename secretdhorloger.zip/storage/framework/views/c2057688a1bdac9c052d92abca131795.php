<?php $__env->startSection("content"); ?>
<?php $__currentLoopData = $product->products_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($langItem["lang"] == config('app.locale')): ?>
<div class="breadcrumb-area">
    <?php if($page[0]->banner_img): ?>
        <img src="<?php echo e(asset($page[0]->banner_img ?? "")); ?>" style="position:absolute; right:0; top:0; width:100%; height:100%; z-index:0;
        opacity: 0.6;" alt="">
    <?php endif; ?>
    <div class="container" style="position: relative; z-index: 6;     background-color: #f0f8ffb5;
    border-radius: 10px;">
        <div class="row">
            <div class="col-12">
                <div class="row breadcrumb_box  align-items-center">
                    <div class="col-lg-6 col-md-6 col-sm-12 text-center text-md-left">
                        <h2 class="breadcrumb-title"><?php echo e($langData["products"]); ?></h2>
                    </div>
                    <div class="col-lg-6  col-md-6 col-sm-12">
                        <ul class="breadcrumb-list text-center text-md-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('homepage')); ?>"><?php echo e($langData["homepage"]); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e($langData["products"]); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="product-details-area pt-100px pb-100px">
    <div class="container">
        <?php
            $producArray = json_decode(json_encode($product), true);
        ?>
        <div class="row">
            <div class="col-lg-5 col-sm-12 col-xs-12 mb-lm-30px mb-md-30px mb-sm-30px">
                <div class="swiper-container zoom-top">
                    <div class="swiper-wrapper">
                        <?php for($i = 1; $i<=5; $i++): ?>
                        <?php
                            $imgWay = "";
                            $imgWay = $producArray["img_".$i];
                        ?>
                         <?php if($imgWay): ?>
                        <div class="swiper-slide zoom-image-hover">
                            <img class="img-responsive m-auto" style="max-height: 350px;" src="<?php echo e(asset($imgWay)); ?>" alt="<?php echo e($product->name); ?>">
                        </div>
                        <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                </div>
                <div class="swiper-container zoom-thumbs slider-nav-style-1 small-nav mt-3 mb-3">
                    <div class="swiper-wrapper">
                        <?php for($i = 1; $i<=5; $i++): ?>
                        <?php
                            $imgWay = "";
                            $imgWay = $producArray["img_".$i];
                        ?>
                        <?php if($imgWay): ?>
                        <div class="swiper-slide">
                            <img class="img-responsive m-auto" src="<?php echo e(asset($imgWay)); ?>" alt="<?php echo e($product->name); ?>">
                        </div>
                        <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <div class="swiper-buttons">
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 col-sm-12 col-xs-12" data-aos="fade-up" data-aos-delay="200">
                <div class="product-details-content quickview-content">
            <h2><?php echo e($langItem["title"]); ?></h2>
                    <p class="reference">SKU:<span> <?php echo e($producArray["sku"]); ?></span></p>
                    <div class="pricing-meta">
                        <ul>
                            <li class="old-price not-cut"><?php echo e($producArray["price"]); ?> €</li>
                        </ul>
                    </div>
                    <p class="quickview-para"><?= $langItem["description"] ?></p>
                    <div class="pro-details-quality">
                        <div class="pro-details-cart">
                            <form action="<?php echo e(route("wishlist.add")); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($producArray['id']); ?>">
                                <input type="hidden" name="product_price" value="<?php echo e($producArray['price']); ?>">
                                <input type="hidden" name="product_qty" value="1">
                                <button title="<?php echo e($langData["addtocart"]); ?>"  class="add-cart btn btn-primary btn-hover-primary " style="background-color: #25D366; border-color:#25D366;" ><?php echo e($langData["addtocart"]); ?></button>
                            </form>
                        </div>
                    </div>
                    <div class="pro-details-social-info">
                        <span><?php echo e($langData["share"]); ?></span>
                        <div class="social-info">
                            <ul class="d-flex">
                                <li>
                                    <a href="https://www.facebook.com/sharer/sharer.php?sdk=joey&u=<?php echo e(url()->current()); ?>&display=popup&ref=plugin&src=share_button&locale=fr_fr" target="_blank"><i class="ion-social-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="whatsapp://send?text=<?php echo e($langData["wp_share"]); ?> <?php echo e(url()->current()); ?>"><i class="ion-social-whatsapp"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="description-review-area pb-100px" data-aos="fade-up" data-aos-delay="200">
    <div class="container">
        <div class="description-review-wrapper">
            <div class="description-review-topbar nav">
                <a data-bs-toggle="tab" href="#des-details1"><?php echo e($langData["description"]); ?></a>
                <a class="active" data-bs-toggle="tab" href="#des-details2"><?php echo e($langData["product_details"]); ?></a>
            </div>
            <div class="tab-content description-review-bottom">
                <div id="des-details2" class="tab-pane active">
                    <div class="product-anotherinfo-wrapper">
                        <?=$langItem["technic_des"]?>
                    </div>
                </div>
                <div id="des-details1" class="tab-pane">
                    <div class="product-description-wrapper">
                        <?=$langItem["description"]?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("frontend.layout.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/frontend/pages/product.blade.php ENDPATH**/ ?>