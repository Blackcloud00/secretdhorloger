<?php $__env->startSection("content"); ?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="row breadcrumb_box  align-items-center">
                    <div class="col-lg-6 col-md-6 col-sm-12 text-center text-md-left">
                        <h2 class="breadcrumb-title"><?php echo e($langData["send_order_page"]); ?></h2>
                    </div>
                    <div class="col-lg-6  col-md-6 col-sm-12">
                        <ul class="breadcrumb-list text-center text-md-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('homepage')); ?>"><?php echo e($langData["homepage"]); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e($langData["send_order_page"]); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="checkout-area pt-100px pb-100px">
    <div class="container">
        <form action="<?php echo e(route("checkout.add")); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-7">
                    <div class="billing-info-wrap">
                        <h3><?php echo e($langData["order_details"]); ?></h3>
                        <div class="row">
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-4">
                                    <label><?php echo e($langData["first_name"]); ?></label>
                                    <input type="text" name="first_name" required />
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-4">
                                    <label><?php echo e($langData["last_name"]); ?></label>
                                    <input type="text" name="last_name" required />
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="billing-info mb-4">
                                    <label><?php echo e($langData["company_name"]); ?></label>
                                    <input type="text" name="company_name" />
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="billing-select mb-4">
                                    <label><?php echo e($langData["country"]); ?></label>
                                    <select name="region">
                                        <option><?php echo e($langData["select_country"]); ?></option>
                                        <option>Azerbaijan</option>
                                        <option>Bahamas</option>
                                        <option>Bahrain</option>
                                        <option>Bangladesh</option>
                                        <option>Barbados</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="billing-info mb-4">
                                    <label><?php echo e($langData["street_address"]); ?></label>
                                    <input class="billing-address" required name="adress_1" placeholder="<?php echo e($langData["adress_place_1"]); ?>" type="text" />
                                    <input placeholder="<?php echo e($langData["adress_place_2"]); ?>"  name="adress_2" type="text" />
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="billing-info mb-4">
                                    <label><?php echo e($langData["town_city"]); ?></label>
                                    <input type="text" required name="city" />
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-4">
                                    <label><?php echo e($langData["state_country"]); ?></label>
                                    <input type="text" name="state" />
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-4">
                                    <label><?php echo e($langData["postcode_zip"]); ?></label>
                                    <input type="text" required name="zip" />
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-4">
                                    <label><?php echo e($langData["phone"]); ?></label>
                                    <input type="text" required name="phone" />
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-4">
                                    <label><?php echo e($langData["email"]); ?></label>
                                    <input type="text" required name="email" />
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-5 mt-md-30px mt-lm-30px ">
                    <div class="your-order-area">
                        <h3><?php echo e($langData["your_order"]); ?></h3>
                        <div class="your-order-wrap gray-bg-4">
                            <div class="your-order-product-info">
                                <div class="your-order-top">
                                    <ul>
                                        <li><?php echo e($langData["product"]); ?></li>
                                        <li><?php echo e($langData["total"]); ?></li>
                                    </ul>
                                </div>
                                <div class="your-order-middle">
                                    <ul>
                                        <?php if(session()->get('wishlist')): ?>
                                        <?php
                                            $i = 1;
                                        ?>
                                        <input type="text" hidden name="count" value="<?php echo e(count(session()->get('wishlist'))); ?>">
                                        <?php $__currentLoopData = session()->get('wishlist'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="text" hidden name="order_item_<?php echo e($i); ?>_id" value="<?php echo e($k); ?>">
                                        <input type="text" hidden name="order_item_<?php echo e($i); ?>_qty" value="<?php echo e($item["qty"]); ?>">
                                        <input type="text" hidden name="order_item_<?php echo e($i); ?>_unit_price" value="<?php echo e($item["price"]); ?>">
                                        <li><span class="order-middle-left"><?php echo e($item["name"]); ?> X <?php echo e($item["qty"]); ?></span> <span class="order-price"><?php echo e($item["price"] * $item["qty"]); ?> € </span></li>
                                        <?php
                                            $i++;
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                <div class="your-order-bottom">
                                    <ul>
                                        <li class="your-order-shipping"><?php echo e($langData["shipping"]); ?></li>
                                        <li><?php echo e($langData["free_shipping"]); ?></li>
                                    </ul>
                                </div>
                                <div class="your-order-total">
                                    <ul>
                                        <input type="text" hidden name="total_price" value="<?php echo e($totalPrice); ?>">
                                        <li class="order-total"><?php echo e($langData["total"]); ?></li>
                                        <li><?php echo e($totalPrice); ?> €</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="Place-order mt-25">
                            <button type="submit" class="btn-hover"><?php echo e($langData["place_order"]); ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("frontend.layout.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/frontend/pages/checkout.blade.php ENDPATH**/ ?>