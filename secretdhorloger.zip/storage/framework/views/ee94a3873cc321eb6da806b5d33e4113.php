<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Ajout d'un curseur</h1>
          </div>
        </div>
        <?php if(session()->get('success')): ?>
        <div class="row mt-3 mb-1 ">
            <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
        </div>
      <?php endif; ?>
      <?php if($errors): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mb-1 ">
            <div class="alert alert-danger"><?php echo e($error); ?></div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      </div>
    </section>
    <section class="content">
        <form action="<?php echo e(route("panel.slider.update",$slider->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
           <div class="row">
                <div class="col-md-12">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Données du curseur</h3>
                    </div>
                    <div class="card-body row">
                      <div class="form-group col-xl-6">
                        <label for="slider_title">Titre du curseur</label>
                        <input type="text" name="slider_title" required id="slider_title" value="<?php echo e($slider->name ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="slider_small_txt">Slider Small Text</label>
                        <input type="text" id="slider_small_txt" required name="slider_small_txt" value="<?php echo e($slider->small_text ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <div class="input-group">
                            <input type="text" class="custom-file-input hidden" value="<?php echo e($slider->image ?? ''); ?>" name="real_slider_image" id="real_slider_image">
                            <img src="<?php echo e(asset($slider->image ?? 'upload/resimyok.jpg')); ?>" style="max-width: 300px; max-height: 300px;" alt="">
                        </div>
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="slider_image" >Image du Curseur</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file" class="custom-file-input"  name="slider_image" id="slider_image">
                            <label class="custom-file-label" for="slider_image">Choisir le fichier (540x458)</label>
                          </div>
                          <div class="input-group-append">
                            <span class="input-group-text">Télécharger</span>
                          </div>
                        </div>
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="slider_lang">Langue</label>
                        <select id="slider_lang" name="slider_lang" required class="form-control custom-select">
                          <option selected  value="<?php echo e($slider->lang ?? ''); ?>"><?php echo e($lang[$slider->lang]); ?></option>
                          <?php if($slider->lang != "fr"): ?>
                          <option value="fr">Français</option>
                          <?php endif; ?>
                          <?php if($slider->lang != "de"): ?>
                          <option value="de">Allemand</option>
                          <?php endif; ?>
                          <?php if($slider->lang != "en"): ?>
                          <option value="en">Anglais</option>
                          <?php endif; ?>
                        </select>
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="slider_status">Statut</label>
                        <select id="slider_status" name="slider_status" required class="form-control custom-select">
                          <option selected value="<?php echo e($slider->status ?? ''); ?>"><?php echo e($status[$slider->status]); ?></option>
                          <?php if($slider->status != "1"): ?>
                          <option value="1">Publier</option>
                          <?php endif; ?>
                          <?php if($slider->status != "0"): ?>
                          <option value="0">Projet</option>
                          <?php endif; ?>
                        </select>
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="slider_link">Lien</label>
                        <input type="text" id="slider_link" name="slider_link"  value="<?php echo e($slider->link ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-6">
                        <label for="btn_txt">Texte du bouton</label>
                        <input type="text" id="btn_txt"  name="btn_txt" value="<?php echo e($slider->button_content ?? ''); ?>" class="form-control">
                      </div>
                      <div class="form-group col-xl-12">
                        <label for="slider_content">Contenu du curseur</label>
                        <textarea id="slider_content" name="slider_content" required class="form-control" rows="4"><?php echo e($slider->content ?? ''); ?></textarea>
                      </div>
                    </div>
                  </div>
                </div>
           </div>
           <div class="row">
                <div class="col-12">
                <a href="#" class="btn btn-secondary">Annuler</a>
                <input type="submit" value="Créer" class="btn btn-success float-right">
                </div>
           </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/backend/pages/slider/edit.blade.php ENDPATH**/ ?>