<?php $__env->startSection("content"); ?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="row breadcrumb_box  align-items-center">
                    <div class="col-lg-6 col-md-6 col-sm-12 text-center text-md-left">
                        <h2 class="breadcrumb-title"><?php echo e($langData["products"]); ?></h2>
                    </div>
                    <div class="col-lg-6  col-md-6 col-sm-12">
                        <ul class="breadcrumb-list text-center text-md-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('homepage')); ?>"><?php echo e($langData["homepage"]); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e($langData["products"]); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="shop-category-area pb-100px pt-70px">

    <div class="container">
        <?php if(session()->get('success')): ?>
        <div class="alert alert-success"><?php echo e($langData[session()->get('success')]); ?></div>
    <?php endif; ?>
        <div class="row">
            <div class="col-lg-9 order-lg-last col-md-12 order-md-first">
                <div class="shop-bottom-area">
                    <div class="row">
                      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $__currentLoopData = $product->products_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($langProduct["lang"] == config('app.locale') && !is_null($product['img_1'])): ?>
                        <div class="col-lg-4  col-md-6 col-sm-6 col-xs-6" data-aos="fade-up" data-aos-delay="200">
                            <div class="product mb-5">
                                <div class="thumb">
                                    <a href="<?php echo e(route('productdetail',$product['slug'])); ?>" class="image">
                                        <img src="<?php echo e(asset($product['img_1'])); ?>" alt="<?php echo e($langProduct["title"]); ?>" />
                                        <img class="hover-image" src="<?php echo e(asset($product['img_1'])); ?>" alt="<?php echo e($langProduct["title"]); ?>" />
                                    </a>
                                    <span class="badges">
                                    </span>
                                    <form action="<?php echo e(route("wishlist.add")); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
                                        <input type="hidden" name="product_price" value="<?php echo e($product['price']); ?>">
                                        <input type="hidden" name="product_qty" value="1">
                                        <button title="<?php echo e($langData["addtocart"]); ?>" class=" add-to-cart"><?php echo e($langData["addtocart"]); ?></button>
                                    </form>
                               </div>
                                <div class="content">
                                    <h5 class="title"><a href="<?php echo e(route('productdetail',$product['slug'])); ?>"><?php echo e($langProduct["title"]); ?></a></h5>
                                    <span class="price">
                                        <span class="new"><?php echo e(number_format($product["price"])); ?> €</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="pro-pagination-style text-center mb-md-30px mb-lm-30px mt-6" data-aos="fade-up">
                        <?php echo e($products->links('pagination::custom')); ?>

                    </div>
                </div>
            </div>
            <div class="col-lg-3 order-lg-first col-md-12 order-md-last mb-md-60px mb-lm-60px">
                <div class="shop-sidebar-wrap">
                    <div class="sidebar-widget">
                        <div class="main-heading">
                            <h3 class="sidebar-title"><?php echo e($langData["categories"]); ?></h3>
                        </div>
                        <div class="sidebar-widget-category">
                            <ul>
                                <?php $__currentLoopData = $mainCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m_catItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($m_catItem->items_count > 0): ?>
                                <li><a href="<?php echo e(route('productscategorie',$m_catItem['slug'])); ?>" class=""><b><?php echo e($m_catItem["name_".app()->getLocale()]); ?> (<?php echo e($m_catItem->items_count); ?>)</b></a></li>
                                    <ul style="padding-left: 15px;">
                                        <?php $__currentLoopData = $subCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s_catItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($s_catItem->parent ==  $m_catItem->id && $s_catItem->items_count > 0): ?>
                                          <li><a href="<?php echo e(route('productscategorie',$s_catItem['slug'])); ?>" class=""><?php echo e($s_catItem["name_".app()->getLocale()]); ?> (<?php echo e($s_catItem->items_count); ?>)</a></li>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("frontend.layout.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/frontend/pages/products.blade.php ENDPATH**/ ?>