<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Ajout d'un curseur</h1>
          </div>
        </div>
        <?php if(session()->get('success')): ?>
        <div class="row mt-3 mb-1 ">
            <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
        </div>
      <?php endif; ?>
      <?php if($errors): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mb-1 ">
            <div class="alert alert-danger"><?php echo e($error); ?></div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      </div>
    </section>
    <section class="content">
           <div class="row">
                <div class="col-md-12">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Données du curseur</h3>
                    </div>
                    <div class="card-body row">
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap">
                              <thead>
                              <tr>
                                <th>ID</th>
                                <th>Nom</th>
                                <th>Data</th>
                                <th>Action</th>
                              </tr>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $sitesetting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                 <form action="<?php echo e(route("panel.sitesetting.update",$item->id)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><input type="text" name="data" required id="data" value="<?php echo e($item->data ?? ''); ?>" class="form-control"></td>
                                    <td style="display: flex; justify-content: start;"><input type="submit" value="Créer" class="btn btn-success float-right"></td>
                                </form>
                                </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                    </div>
                    </div>
                  </div>
                </div>
           </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Olgun\Desktop\LARAVEL\secretdhorloger.com\secretdhorloger\resources\views/backend/pages/sitesetting/edit.blade.php ENDPATH**/ ?>